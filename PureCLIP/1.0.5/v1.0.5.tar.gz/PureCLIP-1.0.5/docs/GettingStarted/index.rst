.. PureCLIP documentation master file, created by
   sphinx-quickstart on Fri Jun 23 12:15:25 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Getting Started
====================================

Before you start, please check the

.. toctree::
   :maxdepth: 2
   :titlesonly:

   requirements

   
For the analysis of your own data, please have a look how to:

.. toctree::
   :maxdepth: 2
   :titlesonly:
 
   preprocessing



    
.. * :ref:`modindex`
.. * :ref:`search`
