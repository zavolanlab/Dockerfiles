.. PureCLIP documentation master file, created by
   sphinx-quickstart on Fri Jun 23 12:15:25 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Simulation Framework
====================================

If you want to simulate your own iCLIP/eCLIP data, please have a look at the `sim_iCLIP git repository <https://github.com/skrakau/sim_iCLIP>`_ and the corresponding `wiki <https://github.com/skrakau/sim_iCLIP/wiki>`_.




