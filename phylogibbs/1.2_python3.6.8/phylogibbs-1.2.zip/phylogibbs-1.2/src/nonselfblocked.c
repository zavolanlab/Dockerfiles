/*                        PhyloGibbs                                  */

/*   Algorithm developed by Rahul Siddharthan, Erik van Nimwegen      * 
 *   and Eric D. Siggia at The Rockefeller University, New York       * 
 *                                                                    *
 *   This code copyright (C) 2004 Rahul Siddharthan <rsidd@online.fr> * 
 *   Licensed under the GNU General Public License (see COPYING)      */ 

/* 
 * $Author: rsidd $  
 * $Date: 2005/05/02 08:54:09 $ 
 * $Id: nonselfblocked.c,v 1.1 2005/05/02 08:54:09 rsidd Exp $ 
 */

#include "interspecies.h"

int nonselfblocked(window *win, int col) {

    int n,blocked;
    window *tempwin;

    blocked=0;
    if (win->blocked==0)
        return 0;

    for (n=0; n<win->blockers->len; n++) {
        tempwin=g_ptr_array_index((win->blockers),n);
        if (tempwin->colour != col)
            blocked=1;
    }

    return blocked;
}
