int estimatepriorparams(params *v);
double get_lambda(double **stirsec,int win,int col);
double get_log_sum(double t1,double t2);
void get_stirling_nums(double **stirsec,int win,int col);
