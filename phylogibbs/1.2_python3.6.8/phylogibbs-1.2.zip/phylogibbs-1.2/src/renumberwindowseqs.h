int renumberwindowseqs(params *v, window *win);
