import sys;

def chomp(string1):  # simple implementation of perl chomp
    if len(string1)==0:
        string2=string1
    elif string1[len(string1)-1]=='\n':
        string2=string1[0:len(string1)-1]
    else:
        string2=string1
    return string2



g=open('printhelp.c','w')

g.write('#include <stdio.h>\n')
g.write('void printhelp() {\n')

f=open('../NOTES','r')
str=f.readline()
while str:
    str2=""
    for n in range(len(str)):
        if str[n]=='"':
            str2=str2+'\\"'
        elif str[n]=='\n':
            pass
        else:
            str2=str2+str[n]
    g.write('    printf("'+str2+'\\n");'+'\n')
    str=f.readline()
   
g.write('}\n')
g.close()
f.close()
