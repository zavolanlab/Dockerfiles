/*                        PhyloGibbs                                  */

/*   Algorithm developed by Rahul Siddharthan, Erik van Nimwegen      * 
 *   and Eric D. Siggia at The Rockefeller University, New York, USA  *
 *   and at The Institute of Mathematical Sciences, Chennai, India    *
 *                                                                    *
 *   This code copyright (C) 2004-2006 Rahul Siddharthan              *
 *   Licensed under the GNU General Public License (see COPYING)      *
 *   For support and contact information, see the webpage:            *
 *             http://www.imsc.res.in/~rsidd/phylogibbs/              */

/* 
 * $Author: rsidd $  
 * $Date: 2006/03/27 18:44:20 $ 
 * $Id: checkwindow.h,v 1.2 2006/03/27 18:44:20 rsidd Exp $ 
 */

int checkwindow(int wwidth, window *win, GArray **seq);
