/*                        PhyloGibbs                                  */

/*   Algorithm developed by Rahul Siddharthan, Erik van Nimwegen      * 
 *   and Eric D. Siggia at The Rockefeller University, New York       * 
 *                                                                    *
 *   This code copyright (C) 2004 Rahul Siddharthan <rsidd@online.fr> * 
 *   Licensed under the GNU General Public License (see COPYING)      */ 

/* 
 * $Author: rsidd $  
 * $Date: 2005/05/20 12:47:39 $ 
 * $Id: setwinbasecount.h,v 1.2 2005/05/20 12:47:39 rsidd Exp $ 
 */

double exactwminteg(int newbase, int newbase2,double offset,GPtrArray **outbasenums);
void setquicklambdas(GArray **bases,double lambda[4],double *c);
void setlambdas(GArray **bases, GArray **mus, GArray **priors, double lambda[4], double *c);
void getbasenumlist_one(int *bases, double *mus, int nbases,GPtrArray **outbasenums, int ancbase);
int setwinbasecount(window *currwin, params *v);
