/*switchwindow move function**/

int switchwindow(params *v,double *logprevweight,int extraregion);
