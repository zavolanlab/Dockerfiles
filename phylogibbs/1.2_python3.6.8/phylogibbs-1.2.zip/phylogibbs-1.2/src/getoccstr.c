/*                        PhyloGibbs                                  */

/*   Algorithm developed by Rahul Siddharthan, Erik van Nimwegen      * 
 *   and Eric D. Siggia at The Rockefeller University, New York       * 
 *                                                                    *
 *   This code copyright (C) 2004 Rahul Siddharthan <rsidd@online.fr> * 
 *   Licensed under the GNU General Public License (see COPYING)      */ 

/* 
 * $Author: rsidd $  
 * $Date: 2005/05/02 08:54:09 $ 
 * $Id: getoccstr.c,v 1.1 2005/05/02 08:54:09 rsidd Exp $ 
 */




#include <glib.h>
#include <stdlib.h>
#include <string.h>

void getoccstr(char *Nstr, GArray **occset, char type) {

    char nstr1[10];
    int n,m,occ1;
    double occd;

    n=0;
    m=0;
    if ((*occset)!=NULL)
        g_array_free((*occset),TRUE);
    if (type=='f')
        (*occset)=g_array_new(TRUE,TRUE,sizeof(double));
    else
        (*occset)=g_array_new(TRUE,TRUE,sizeof(int));

    while (Nstr[n]!=0) {
        if ((Nstr[n]=='0')||(Nstr[n]=='1')||(Nstr[n]=='2')||(Nstr[n]=='3')||
                        (Nstr[n]=='4')||(Nstr[n]=='5')||(Nstr[n]=='6')||
                        (Nstr[n]=='7')|| (Nstr[n]=='8')|| (Nstr[n]=='9')
                        ||(Nstr[n]=='.')) {
            nstr1[m++]=Nstr[n];
        }
        if (Nstr[n]==',') {
            nstr1[m]=0;
            if (type=='f') {
                occd=atof(nstr1);
                g_array_append_val((*occset),occd);
            } else {
                occ1=atoi(nstr1);
                g_array_append_val((*occset),occ1);
            }
            m=0;
        }
        n++;
    }
    nstr1[m]=0;
    if (type=='f') {
        occd=atof(nstr1);
        g_array_append_val((*occset),occd);
    } else {
        occ1=atoi(nstr1);
        g_array_append_val((*occset),occ1);
    }
}
