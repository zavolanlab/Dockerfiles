/*                        PhyloGibbs                                  */

/*   Algorithm developed by Rahul Siddharthan, Erik van Nimwegen      * 
 *   and Eric D. Siggia at The Rockefeller University, New York       * 
 *                                                                    *
 *   This code copyright (C) 2004 Rahul Siddharthan <rsidd@online.fr> * 
 *   Licensed under the GNU General Public License (see COPYING)      */ 

/* 
 * $Author: rsidd $  
 * $Date: 2005/04/29 18:38:57 $ 
 * $Id: wminteg.h,v 1.4 2005/04/29 18:38:57 rsidd Exp $ 
 */

void inittables(double pseudocount);
extern inline double gam_ratio_q(double n1);
extern inline double gam_ratio_4q(double n1);
double wminteg(double n1, double n2, double n3, double n4);
double precise_wminteg(double n1, double n2,double n3,double n4);
