/* macro to print progress bar */
#define show_progress_bar(n1,ntot) \
 do { printf("\r|                              |\r|");\
 for (nprog=0; nprog< (n1*30/ntot); nprog++) printf("#"); fflush(NULL);} while (0)

int substring(char *s1, char *s2);
char* twodigitstr(int m);
char consensus(double na, double nc, double ng, double nt); 
double infscore(double na, double nc, double ng, double nt);
GArray* stripdash(GArray *seqs);	
void destroy_gptrarray_array(GPtrArray **gptr); 
